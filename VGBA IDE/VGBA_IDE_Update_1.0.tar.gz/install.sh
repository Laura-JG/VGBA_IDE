#!/bin/bash
#VGBAIDEINSTALL
echo 
echo UPDATING VGBA_IDE...
yes|cp VGBA_IDE_RUNABLE.jar $HOME/VGBA_IDE/
yes|cp readme.txt $HOME/VGBA_IDE/
echo DONE!
exit 0
