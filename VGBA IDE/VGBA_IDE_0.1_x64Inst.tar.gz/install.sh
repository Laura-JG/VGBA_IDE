#!/bin/bash
echo Installing DevKitPro suite

#DevKitPro_INST
sudo mkdir -p /opt/devkitpro
sudo mkdir -p /opt/devkitpro/libgba
sudo chmod 777 /opt/devkitpro
sudo tar -xvjf devkitARM.tar.bz2 -C /opt/devkitpro/ >/dev/null
sudo tar -xvjf libgba.tar.bz2 -C /opt/devkitpro/libgba/ >/dev/null

#VGBAIDEINSTALL
echo 
echo Installing VGBA_IDE
mkdir -p ~/VGBA_IDE
sudo tar xvfz VGBA_IDE.tar.gz -C $HOME/VGBA_IDE/ >/dev/null
echo Creating LINKS
#Link Generation
echo [Desktop Entry] >VGBA_IDE.desktop
echo Comment=Integrated Development environment for DevkitPRO\'s suite >>VGBA_IDE.desktop
echo Name=VGBA_IDE >>VGBA_IDE.desktop
echo Exec=/bin/bash -c \"java -jar $HOME/VGBA_IDE/VGBA_IDE_RUNABLE.jar\" >>VGBA_IDE.desktop
echo Terminal=false >>VGBA_IDE.desktop
echo Type=Application >>VGBA_IDE.desktop
echo Icon=$HOME/VGBA_IDE/VGBA_IDE.xpm >>VGBA_IDE.desktop
echo Categories=Development >>VGBA_IDE.desktop
cp VGBA_IDE.desktop $HOME/.local/share/applications
sudo cp VGBA_IDE.desktop /usr/share/applications


#GVBA INSTALL
command -v apt-get >/dev/null 2>&1 || { echo >&2 "COULDNT INSTALL GVBA, apt-get doesnt exist, install it later, Compile and run functionality wont work (pkg name: visualboyadvance-gtk)";cd $HOME;echo export DEVKITPRO=/opt/devkitpro >> .bashrc;echo export DEVKITARM=$DEVKITPRO/devkitARM >> .bashrc;exit 1;}
echo Updating packages list...
sudo apt-get update > /dev/null
echo Installing visualboyadvance-gtk
sudo apt-get install visualboyadvance-gtk

#finally
echo Exporting variables...
cd $HOME
echo export DEVKITPRO=/opt/devkitpro >> .bashrc
echo export DEVKITARM=$DEVKITPRO/devkitARM >> .bashrc
echo DONE!
exit 0
